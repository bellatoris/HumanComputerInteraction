# 빅 데이터 아카데미 5회차 실습자료

서울대학교 빅 데이터 아카데미 실습자료입니다.

위쪽의 "Download ZIP" 버튼을 클릭하시거나 [여기](https://github.com/SNU-HCIL/2016-SNUBDA-Summer-Engineering/archive/master.zip)를 클릭해 전체 자료를 다운로드 받으실 수 있습니다.
